-- This script just exists so that pcall(require, "Switcheroo.Switcheroo") returns true!
-- All code is in other scripts.
return {}
